package service;

import java.util.List;
import java.util.Objects;
import model.RobotRescate;

public interface ServicioRobots {

    public static void mostrarRobots(List<? extends RobotRescate> lista) {
        for (RobotRescate robot : lista) {
            System.out.println(robot);
        }

    }

    public static void cargarRobotsDePrueba(List<? super RobotRescate> robotsDemo) {
        Objects.requireNonNull(robotsDemo);

        robotsDemo.forEach(System.out::println);
        System.out.println("-------------------------");
    }
}
