package util;

import java.io.File;

public interface ArchivosUtil {
    static void crearCarpetaSiNoExiste(String path) {
        File archivo = new File(path);

        if (!archivo.exists()) {
            archivo.mkdir();
        }
    }
}
