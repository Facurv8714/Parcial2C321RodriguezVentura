package config;

public interface AppConfig {
    String PATH_DATA ="src/data/";
    String ARCHIVO_CSV = PATH_DATA + "centro.csv";
    String ARCHIVO_BINARIO = PATH_DATA + "centro.dat";
    String ARCHIVO_TXT = PATH_DATA + "centro.txt";
    String TITULO_REPORTE = "REPORTE DE ROBOTS DE RESCATE";
}
