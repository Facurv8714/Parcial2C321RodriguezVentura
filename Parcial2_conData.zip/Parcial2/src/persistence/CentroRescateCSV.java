package persistence;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import model.RobotRescate;

public interface CentroRescateCSV<T> {

    static <T> void guardarCentroRescateCSV(List<? extends T> lista, String path, String encabezado) {
        if (lista.isEmpty()) {
            System.out.println("no hay nada por guardar");
        } else {
            try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
                escritor.write(encabezado + "\n");
                for (T item : lista) {
                    if (item instanceof RobotRescate) {
                        escritor.write(((RobotRescate) item).toCSV() + "\n");
                    }
                }
                System.out.println("Centro guardados con exito");
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    // VER QUE PASA CON MAPEADOR
    static <T> List<T> cargarCentroRescateCSV(String path, Function<String, T> mapeador) {
            List<T> toReturn = new ArrayList<>();

        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {
            String linea;

            lector.readLine();

            while ((linea = lector.readLine()) != null) {
                toReturn.add(mapeador.apply(linea));
            }

            System.out.println("Lista cargada desde csv! ");
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        return toReturn;
    }
}
