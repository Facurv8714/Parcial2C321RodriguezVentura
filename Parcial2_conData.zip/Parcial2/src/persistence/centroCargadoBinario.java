/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package persistence;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

public interface centroCargadoBinario<T> {

    static <T> void serializarCentroRescate(List<? extends T> lista, String path) {

        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(path))) {
            serializador.writeObject(lista);
            System.out.println("Archivo guardado con exito");
        } catch (FileNotFoundException ex) {
            System.out.println("No se encontro el archivo");
        } catch (IOException ex) {
            System.out.println("Error al guardar el centro");
        }
    }

    ;

    // Otra posible expcepción IndexOutboundExceptions
    
    static <T> List<T> deserializarCentroRescate(String path) {
        List<T> toReturn = null;

        try (ObjectInputStream deserializador = new ObjectInputStream(new FileInputStream(path))) {

            toReturn = (List<T>) deserializador.readObject();

            System.out.println("Archivo cargado con exito");

        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            System.out.println("Error al cargar el archivo");
        } finally {
            return toReturn;
        }
    }
}
