package persistence;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import model.RobotRescate;

public interface CentroRescateTXT {

    static <T> void guardarCentroRescateTXT(List<? extends T> lista, String path, String titulo) {
        if (lista.isEmpty()) {
            System.out.println("no hay nada por guardar");
        } else {
            try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
                escritor.write(titulo + "\n");
                escritor.write("----------------------------");
                for (T item : lista) {
                    if (item instanceof RobotRescate) {
                        escritor.write(item + "\n");
                    }
                }
                System.out.println("Centro guardados con exito");
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }



}
