package app;

import config.AppConfig;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import model.CentroRescate;
import model.GestionCentro;
import model.RobotRescate;
import model.TipoRobot;
import service.ServicioRobots;

public class Principal {

    public static void main(String[] args) {
        CentroRescate<RobotRescate> centro = new CentroRescate<>();
        centro.agregar(new RobotRescate(1, "RX-Terra", "Boston Dynamics", 140,
                TipoRobot.TERRESTRE));
        centro.agregar(new RobotRescate(2, "MediBot Pro", "RescueTech", 180,
                TipoRobot.MEDICO));
        centro.agregar(new RobotRescate(3, "SkyScan RX", "AeroSafe", 100,
                TipoRobot.AEREO));
        centro.agregar(new RobotRescate(4, "DeepRescue", "Oceanic Labs", 160,
                TipoRobot.ACUATICO));
        centro.agregar(new RobotRescate(5, "CargoMax", "Boston Dynamics", 120,
                TipoRobot.CARGA));
        centro.agregar(new RobotRescate(6, "Explorer Mini", "RescueTech", 80,
                TipoRobot.EXPLORADOR));
        System.out.println("ROBOTS CARGADOS:");
        centro.paraCadaElemento(elemento -> System.out.println(elemento.toString()));
        System.out.println("\nROBOTS DE TIPO MEDICO:");
        centro.filtrar(elemento -> elemento.getTipo() == TipoRobot.MEDICO).forEach(System.out::println);
        System.out.println("\nROBOTS CON AUTONOMÍA MAYOR O IGUAL A 120 MINUTOS:");
        centro.filtrar(elemento -> elemento.getAutonomia() >= 120).forEach(System.out::println);
        System.out.println("\nROBOTS CUYO MODELO CONTIENE 'RX':");
        centro.filtrar(elemento -> elemento.getModelo().contains("RX")).forEach(elemento -> System.out.println(elemento));
        System.out.println("\nROBOTS ORDENADOS POR ID:");
        centro.ordenar();
        centro.paraCadaElemento(elemento -> System.out.println(elemento));
        System.out.println("\nROBOTS ORDENADOS POR MODELO:");
        centro.ordenar((r1, r2) -> r1.getModelo().compareTo(r2.getModelo()));
        centro.paraCadaElemento(elemento -> System.out.println(elemento));
        System.out.println("\nROBOTS ORDENADOS POR AUTONOMÍA DE MAYOR A MENOR:");
        centro.ordenar((r1, r2) -> Integer.compare(r2.getAutonomia(), r1.getAutonomia()));
        centro.paraCadaElemento(elemento -> System.out.println(elemento));
        System.out.println(
                "\nROBOTS ORDENADOS POR FABRICANTE Y, EN CASO DE EMPATE, POR AUTONOMÍA:");
        centro.ordenar((r1, r2) -> {
            int resultado = r1.getFabricante().compareTo(r2.getFabricante());

            if (resultado == 0) {
                return Integer.compare(r1.getAutonomia(), r2.getAutonomia());
            }

            return resultado;
        });
        centro.paraCadaElemento(elemento -> System.out.println(elemento));
        centro.guardarEnArchivo(AppConfig.ARCHIVO_BINARIO);
        CentroRescate<RobotRescate> centroCargadoBinario = new CentroRescate<>();
        centroCargadoBinario.cargarDesdeArchivo(AppConfig.ARCHIVO_BINARIO);
        System.out.println("\nROBOTS CARGADOS DESDE ARCHIVO BINARIO:");
        centro.paraCadaElemento(elemento -> System.out.println(elemento));
        centro.guardarEnCSV(AppConfig.ARCHIVO_CSV, RobotRescate.getCSVHeader());
        CentroRescate<RobotRescate> centroCargadoCSV = new CentroRescate<>();
        centroCargadoCSV.cargarDesdeCSV(AppConfig.ARCHIVO_CSV, linea -> RobotRescate.fromCSV(linea));
        System.out.println("\nROBOTS CARGADOS DESDE ARCHIVO CSV:");
        centro.paraCadaElemento(elemento -> System.out.println(elemento));
        centro.exportarTXT(AppConfig.ARCHIVO_TXT, AppConfig.TITULO_REPORTE);
        System.out.println("\nMOSTRAR ROBOTS USANDO SERVICIO:");
        List<? extends RobotRescate> robotsParaMostrar = centro.obtenerTodos();
        ServicioRobots.mostrarRobots(robotsParaMostrar);
        System.out.println("\nCARGAR ROBOTS DE PRUEBA USANDO SERVICIO:");
        List<RobotRescate> robotsDemo = new ArrayList<>();
        ServicioRobots.cargarRobotsDePrueba(robotsDemo);
        for (RobotRescate robot : robotsDemo) {
            centro.agregar(robot);
        }
        System.out.println("\nROBOTS LUEGO DE AGREGAR LOS DE PRUEBA:");
        centro.paraCadaElemento(elemento -> System.out.println(elemento));
        List< ? super RobotRescate> destinoGenerico = new ArrayList<Object>();
        ServicioRobots.cargarRobotsDePrueba(destinoGenerico);

    }
}
