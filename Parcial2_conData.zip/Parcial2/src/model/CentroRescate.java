package model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import persistence.CentroRescateCSV;
import persistence.CentroRescateTXT;
import persistence.centroCargadoBinario;

public class CentroRescate<T> implements Iterable<T> {

    private final List<T> items = new ArrayList<>();

    public void agregar(T elemento) {
        Objects.requireNonNull(elemento, "Elemento invalido");
        items.add(elemento);
    }

    ;
    
    private void validarIndice(int indice) {
        Objects.requireNonNull(indice, "Indice invalido");
        if (items.size() < indice) {
            throw new IndexOutOfBoundsException("Elemento no encontrado");
        }
    }

    public T obtener(int indice) {
        validarIndice(indice);
        return items.get(indice);
    }

    ;

    public void eliminar(int indice) {
        validarIndice(indice);
        items.remove(indice);
    }

    ;

    public List<T> filtrar(Predicate<? super T> criterio) {
        Objects.requireNonNull(criterio, "Criterio invalido");
        List<T> nuevaLista = new ArrayList<>();

        for (T item : items) {
            if (criterio.test(item)) {
                nuevaLista.add(item);
            }
        }

        return nuevaLista;
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        Objects.requireNonNull(accion, "Accion invalido");
        items.forEach(item -> accion.accept(item));
    }

    private void validarListaVacia() {
        if (items.isEmpty()) {
            throw new IllegalStateException("La lista esta vacia");
        }
    }

    public void ordenar() {
        validarListaVacia();
        if (items.getFirst() instanceof Comparable) {
            Comparator.naturalOrder();
        }
    }

    public void ordenar(Comparator<? super T> comparador){
        validarListaVacia();
        items.sort(comparador);        
    }

    public void guardarEnArchivo(String ruta){
        centroCargadoBinario.serializarCentroRescate(items, ruta);
    };

    public void cargarDesdeArchivo(String ruta){
        centroCargadoBinario.deserializarCentroRescate(ruta);
    }
    
    public void guardarEnCSV(String ruta, String encabezado){
        // Ver como pasarle el .toCSV()
        CentroRescateCSV.guardarCentroRescateCSV(items, ruta, encabezado);
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> mapeador){
        CentroRescateCSV.cargarCentroRescateCSV(ruta, mapeador);
    }

    public void exportarTXT(String ruta, String titulo){
        CentroRescateTXT.guardarCentroRescateTXT(items, ruta, titulo);
    }

    public List<T> obtenerTodos(){
        return items;
    };

    @Override
    public Iterator<T> iterator() {
        return items.iterator();
    }

}
