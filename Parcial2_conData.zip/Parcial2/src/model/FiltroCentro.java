package model;

@FunctionalInterface
public interface FiltroCentro<T> {

   <T> boolean test(T centro);
}