package model;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public interface GestionCentro<T> {
    static <T> List<T> filtrarTareas(List<? extends T> centro, FiltroCentro filtro){
        List<T> toReturn = new ArrayList<>();
        
        for(T t : centro) {
            if(filtro.test(t)){
                toReturn.add(t);
            }
        }
        return toReturn;
    }
        
    /*
    // como mejorar esto -> static void ordenarTareas(List<? extends Tarea> tareas, Comparator<Tarea> criterio){
        
    static void ordenarTareas(List<? extends Tarea> tareas, Comparator<? super Tarea> criterio){
        
           tareas.sort(criterio);
    }
    
    static void aplicarAccion(List<? extends Tarea> tareas, AccionTarea accion){
        for(Tarea t : tareas){
            accion.ejecutar(t);
        }
        
        /* También puede ir así:
        // Consumer? Interfaz que viene de java?
        // Un consumer recibe una lamba con el formato recibo algo y no devuelvo nada
        
            tareas.forEach(t -> accion.ejecutar(t));
        
        */
        /*
            // otra forma de hacerlo
            // Esto se llama: Referencia método
            // Creo que es lo mismo que hacer accion.ejecutar();
            
            tareas.forEach(accion::ejecutar);
        */
        /*
            // otra forma de hacerlo
            // Este rompe
            tareas.forEach((Consumer<Tarea>) accion);
        */
    }
   

