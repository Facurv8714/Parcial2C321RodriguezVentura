package model;

import config.AppConfig;
import java.io.IOException;
import java.io.Serializable;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class RobotRescate implements Comparable<RobotRescate>, Serializable, CSVSerializable {

    private static final long serialVersionUID = 1L;
    private static final String HEADER = "id,modelo,fabricante,autonomia,tipo";
    private int id;
    private String modelo;
    private String fabricante;
    private int autonomia;
    private TipoRobot tipo;

    public RobotRescate(int id, String modelo, String fabricante, int autonomia, TipoRobot tipo) {
        this.id = id;
        this.modelo = modelo;
        this.fabricante = fabricante;
        this.autonomia = autonomia;
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "RobotRescate{" + "id=" + id + ", modelo=" + modelo + ", fabricante=" + fabricante + ", autonomia=" + autonomia + ", tipo=" + tipo + '}';
    }

    public TipoRobot getTipo() {
        return tipo;
    }

    public String getModelo() {
        return modelo;
    }
    

    public int getAutonomia() {
        return autonomia;
    }
    
    public static String getCSVHeader(){
        return HEADER;
    } 
    

    @Override
    public int compareTo(RobotRescate robot) {
        // return legajo - o.legajo;
        return Integer.compare(id, robot.id);
    }

    public String toCSV() {
        return id + "," + modelo + "," + fabricante + "," + autonomia + "," + tipo;
    }

    public static RobotRescate fromCSV(String linea) {
        // Completar
        RobotRescate nuevoRobot = new RobotRescate(1, "nombre", "Samsung", 12, TipoRobot.ACUATICO);
        return nuevoRobot;
    }

    public String getFabricante() {
        return fabricante;
    }

    
}
